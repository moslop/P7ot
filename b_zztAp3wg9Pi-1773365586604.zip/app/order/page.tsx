"use client"

import { useState } from "react"
import { useLanguage } from "@/context/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Send, CheckCircle, FileText, Clock, Shield } from "lucide-react"

export default function OrderPage() {
  const { t, language } = useLanguage()
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    description: "",
  })

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    
    try {
      const response = await fetch("https://formspree.io/f/xqeybwed", {
        method: "POST",
        body: new FormData(e.currentTarget),
        headers: {
          Accept: "application/json",
        },
      })
      
      if (response.ok) {
        setIsSubmitted(true)
      } else {
        alert(language === "ar" ? "حدث خطأ، يرجى المحاولة مرة أخرى" : "An error occurred, please try again")
      }
    } catch {
      alert(language === "ar" ? "حدث خطأ، يرجى المحاولة مرة أخرى" : "An error occurred, please try again")
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const features = [
    {
      icon: FileText,
      text: language === "ar" ? "استشارة مجانية" : "Free Consultation",
    },
    {
      icon: Clock,
      text: language === "ar" ? "رد سريع خلال 24 ساعة" : "Response within 24h",
    },
    {
      icon: Shield,
      text: language === "ar" ? "معلوماتك آمنة 100%" : "100% Secure Info",
    },
  ]

  if (isSubmitted) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center bg-background px-4">
        <Card className="max-w-md w-full text-center border-border animate-in zoom-in-95 fade-in duration-500">
          <CardContent className="pt-12 pb-10">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-3">
              {t("order.success")}
            </h2>
            <p className="text-muted-foreground mb-8">
              {language === "ar"
                ? "سنتواصل معك قريباً عبر الهاتف المُدخل"
                : "We will contact you soon via the phone number provided"}
            </p>
            <Button
              onClick={() => {
                setIsSubmitted(false)
                setFormData({ firstName: "", lastName: "", phone: "", description: "" })
              }}
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              {language === "ar" ? "إرسال طلب جديد" : "Submit Another Order"}
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header Section */}
      <div className="bg-primary py-16 md:py-20 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-primary-foreground rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-64 h-64 bg-primary-foreground rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary-foreground mb-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {t("order.title")}
            </h1>
            <p className="text-lg text-primary-foreground/80 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-100">
              {t("order.subtitle")}
            </p>
          </div>
        </div>

        {/* Bottom Wave */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
            <path d="M0 80L80 70C160 60 320 40 480 35C640 30 800 40 960 45C1120 50 1280 50 1360 50L1440 50V80H1360C1280 80 1120 80 960 80C800 80 640 80 480 80C320 80 160 80 80 80H0Z" fill="var(--background)" />
          </svg>
        </div>
      </div>

      {/* Form Section */}
      <div className="container mx-auto px-4 -mt-8 pb-20">
        <div className="max-w-2xl mx-auto">
          {/* Features */}
          <div className="flex flex-wrap items-center justify-center gap-6 mb-10">
            {features.map((feature, index) => (
              <div
                key={index}
                className="flex items-center gap-2 text-sm text-muted-foreground animate-in fade-in duration-500"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <feature.icon className="w-4 h-4 text-primary" />
                <span>{feature.text}</span>
              </div>
            ))}
          </div>

          {/* Form Card */}
          <Card className="border-border shadow-lg animate-in fade-in slide-in-from-bottom-4 duration-500 delay-200">
            <CardHeader className="pb-0">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-2">
                <Send className="w-6 h-6 text-primary" />
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label
                      htmlFor="firstName"
                      className="text-sm font-medium text-foreground"
                    >
                      {t("order.firstName")}
                      <span className="text-muted-foreground ms-1">
                        ({language === "ar" ? "الاسم الأول" : "First Name"})
                      </span>
                    </label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleChange}
                      required
                      className="h-12 border-border focus:border-primary focus:ring-primary"
                      placeholder={language === "ar" ? "أدخل اسمك الأول" : "Enter your first name"}
                    />
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="lastName"
                      className="text-sm font-medium text-foreground"
                    >
                      {t("order.lastName")}
                      <span className="text-muted-foreground ms-1">
                        ({language === "ar" ? "اللقب" : "Last Name"})
                      </span>
                    </label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleChange}
                      required
                      className="h-12 border-border focus:border-primary focus:ring-primary"
                      placeholder={language === "ar" ? "أدخل لقبك" : "Enter your last name"}
                    />
                  </div>
                </div>

                {/* Phone Field */}
                <div className="space-y-2">
                  <label
                    htmlFor="phone"
                    className="text-sm font-medium text-foreground"
                  >
                    {t("order.phone")}
                    <span className="text-muted-foreground ms-1">
                      ({language === "ar" ? "رقم الهاتف" : "Phone Number"})
                    </span>
                  </label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="h-12 border-border focus:border-primary focus:ring-primary"
                    placeholder={language === "ar" ? "أدخل رقم هاتفك" : "Enter your phone number"}
                    dir="ltr"
                  />
                </div>

                {/* Description Field */}
                <div className="space-y-2">
                  <label
                    htmlFor="description"
                    className="text-sm font-medium text-foreground"
                  >
                    {t("order.description")}
                    <span className="text-muted-foreground ms-1">
                      ({language === "ar" ? "الوصف الدقيق" : "Detailed Description"})
                    </span>
                  </label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="resize-none border-border focus:border-primary focus:ring-primary"
                    placeholder={t("order.descriptionPlaceholder")}
                  />
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-14 bg-primary text-primary-foreground hover:bg-primary/90 text-lg font-semibold rounded-xl transition-all hover:scale-[1.02] disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      <span>{language === "ar" ? "جاري الإرسال..." : "Submitting..."}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3">
                      <Send className="w-5 h-5" />
                      <span>{t("order.submit")}</span>
                    </div>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Privacy Note */}
          <p className="text-center text-sm text-muted-foreground mt-6">
            {language === "ar"
              ? "جميع المعلومات المُدخلة سرية ومحمية بالكامل"
              : "All information submitted is completely confidential and protected"}
          </p>
        </div>
      </div>
    </div>
  )
}
