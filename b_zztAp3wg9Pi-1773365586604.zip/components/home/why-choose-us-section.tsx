"use client"

import { Award, Clock, Lock, CheckCircle } from "lucide-react"
import { useLanguage } from "@/context/language-context"

const reasons = [
  {
    icon: Award,
    titleKey: "why.quality.title",
    descKey: "why.quality.description",
    accent: "from-blue-500 to-cyan-500",
  },
  {
    icon: Clock,
    titleKey: "why.speed.title",
    descKey: "why.speed.description",
    accent: "from-emerald-500 to-teal-500",
  },
  {
    icon: Lock,
    titleKey: "why.confidential.title",
    descKey: "why.confidential.description",
    accent: "from-violet-500 to-purple-500",
  },
]

export function WhyChooseUsSection() {
  const { t, language } = useLanguage()

  return (
    <section className="py-20 md:py-28 bg-secondary/30">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            {t("why.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            {t("why.subtitle")}
          </p>
        </div>

        {/* Reasons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {reasons.map((reason, index) => (
            <div
              key={reason.titleKey}
              className="group relative"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {/* Card */}
              <div className="relative bg-card rounded-2xl p-8 border border-border shadow-sm hover:shadow-lg transition-all duration-300 h-full">
                {/* Numbered Badge */}
                <div className="absolute -top-4 -left-4 rtl:-right-4 rtl:left-auto w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center text-lg shadow-lg">
                  {index + 1}
                </div>

                {/* Icon Container */}
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <reason.icon className="w-8 h-8 text-primary" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {t(reason.titleKey)}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {t(reason.descKey)}
                </p>

                {/* Checkmarks */}
                <div className="mt-6 pt-6 border-t border-border">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span>
                      {language === "ar" ? "مضمون ومجرب" : "Guaranteed & Tested"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
