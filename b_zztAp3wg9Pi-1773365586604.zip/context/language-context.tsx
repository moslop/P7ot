"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type Language = "en" | "ar"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
  dir: "ltr" | "rtl"
}

const translations = {
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.order": "Order Now",
    "nav.language": "العربية",
    
    // Hero Section
    "hero.title": "Academic Research Excellence",
    "hero.subtitle": "Your Partner in Academic Success",
    "hero.description": "We provide professional research assistance services to help you achieve your academic goals with excellence and precision.",
    "hero.cta": "Start Your Project",
    
    // Services Section
    "services.title": "Our Services",
    "services.subtitle": "Comprehensive academic support tailored to your needs",
    "services.thesis.title": "Thesis Writing",
    "services.thesis.description": "Complete thesis and dissertation writing services with original research and proper academic formatting.",
    "services.research.title": "Research Papers",
    "services.research.description": "High-quality research papers with thorough analysis and proper citations following your required style.",
    "services.literature.title": "Literature Review",
    "services.literature.description": "Comprehensive literature reviews that synthesize relevant sources and identify research gaps.",
    "services.data.title": "Data Analysis",
    "services.data.description": "Expert statistical analysis using SPSS, R, or Python with clear interpretation of results.",
    
    // Why Choose Us Section
    "why.title": "Why Choose Us",
    "why.subtitle": "We are committed to your academic success",
    "why.quality.title": "Premium Quality",
    "why.quality.description": "Rigorous quality control and expert researchers ensure exceptional academic work.",
    "why.speed.title": "Fast Delivery",
    "why.speed.description": "Meet your deadlines with our efficient process and timely delivery guarantee.",
    "why.confidential.title": "100% Confidential",
    "why.confidential.description": "Your privacy is paramount. All projects are handled with strict confidentiality.",
    
    // CTA Section
    "cta.title": "Ready to Start?",
    "cta.description": "Take the first step towards academic excellence. Contact us today for a free consultation.",
    "cta.button": "Place Your Order",
    
    // Order Page
    "order.title": "Place Your Order",
    "order.subtitle": "Fill out the form below and we will get back to you shortly",
    "order.firstName": "First Name",
    "order.lastName": "Last Name",
    "order.phone": "Phone Number",
    "order.description": "Detailed Description of Request",
    "order.descriptionPlaceholder": "Please describe your project requirements in detail...",
    "order.submit": "Submit Order",
    "order.success": "Your order has been submitted successfully!",
    
    // Footer
    "footer.rights": "All rights reserved",
  },
  ar: {
    // Navigation
    "nav.home": "الرئيسية",
    "nav.order": "اطلب الآن",
    "nav.language": "English",
    
    // Hero Section
    "hero.title": "التميز في البحث الأكاديمي",
    "hero.subtitle": "شريكك في النجاح الأكاديمي",
    "hero.description": "نقدم خدمات مساعدة بحثية احترافية لمساعدتك على تحقيق أهدافك الأكاديمية بتميز ودقة.",
    "hero.cta": "ابدأ مشروعك",
    
    // Services Section
    "services.title": "خدماتنا",
    "services.subtitle": "دعم أكاديمي شامل مصمم خصيصاً لاحتياجاتك",
    "services.thesis.title": "كتابة الأطروحات",
    "services.thesis.description": "خدمات كتابة الأطروحات والرسائل الجامعية الكاملة مع بحث أصيل وتنسيق أكاديمي سليم.",
    "services.research.title": "الأوراق البحثية",
    "services.research.description": "أوراق بحثية عالية الجودة مع تحليل شامل واقتباسات سليمة وفق الأسلوب المطلوب.",
    "services.literature.title": "مراجعة الأدبيات",
    "services.literature.description": "مراجعات أدبية شاملة تلخص المصادر ذات الصلة وتحدد الفجوات البحثية.",
    "services.data.title": "تحليل البيانات",
    "services.data.description": "تحليل إحصائي متخصص باستخدام SPSS و R و Python مع تفسير واضح للنتائج.",
    
    // Why Choose Us Section
    "why.title": "لماذا تختارنا",
    "why.subtitle": "نحن ملتزمون بنجاحك الأكاديمي",
    "why.quality.title": "جودة متميزة",
    "why.quality.description": "رقابة جودة صارمة وباحثون متخصصون يضمنون عملاً أكاديمياً استثنائياً.",
    "why.speed.title": "تسليم سريع",
    "why.speed.description": "التزم بمواعيدك النهائية مع عمليتنا الفعالة وضمان التسليم في الوقت المحدد.",
    "why.confidential.title": "سرية تامة 100%",
    "why.confidential.description": "خصوصيتك هي الأهم. يتم التعامل مع جميع المشاريع بسرية تامة.",
    
    // CTA Section
    "cta.title": "هل أنت مستعد للبدء؟",
    "cta.description": "اتخذ الخطوة الأولى نحو التميز الأكاديمي. تواصل معنا اليوم للحصول على استشارة مجانية.",
    "cta.button": "قدم طلبك",
    
    // Order Page
    "order.title": "قدم طلبك",
    "order.subtitle": "املأ النموذج أدناه وسنتواصل معك قريباً",
    "order.firstName": "الاسم الأول",
    "order.lastName": "اللقب",
    "order.phone": "رقم الهاتف",
    "order.description": "الوصف الدقيق للطلب",
    "order.descriptionPlaceholder": "يرجى وصف متطلبات مشروعك بالتفصيل...",
    "order.submit": "إرسال الطلب",
    "order.success": "تم إرسال طلبك بنجاح!",
    
    // Footer
    "footer.rights": "جميع الحقوق محفوظة",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  useEffect(() => {
    const saved = localStorage.getItem("language") as Language
    if (saved && (saved === "en" || saved === "ar")) {
      setLanguage(saved)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("language", language)
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr"
    document.documentElement.lang = language
  }, [language])

  const t = (key: string): string => {
    return translations[language][key as keyof (typeof translations)["en"]] || key
  }

  const dir = language === "ar" ? "rtl" : "ltr"

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, dir }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
